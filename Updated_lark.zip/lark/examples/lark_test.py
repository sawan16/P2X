from lark import Lark

l = Lark(open("python3.lark"), parser="lalr")

print( l.parse("def xyz():") )
