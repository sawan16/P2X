import numpy as np
import pandas as pd
def func1():
	pass

print("data")
